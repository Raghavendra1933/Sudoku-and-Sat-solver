How to Build and Run the code:

For the first part:

Enter the file name in 7th line inside the with open command. Example: with open("test_case_2.csv"), etc.
Then Run the code with pysat installed, when the terminal prompted, Enter the value of k.
Then The code reads the file and displays the output.

For the second part:

As in this case, there is no need to read a document, Just enter the value of k. 
Note: Two random generated sudokus with s1[i][j]!=s2[i][j] are displayed.
