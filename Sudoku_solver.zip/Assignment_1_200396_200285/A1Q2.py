from pysat.solvers import Glucose3
import math
import numpy as np
import csv
import random

    
# scanning the value of k
k=int(input("Enter Value of K "))
n=pow(k,2)
a=[[0 for i in range(n)] for j in range(2*n)]
b=[i+1 for i in range(n)]
random.shuffle(b)

#storing input in two seperate sudokus 
sud_1=[]
for i in range(n):
    sud_1.append(a[i])
sud_2=[]
for i in range(n):
    sud_2.append(a[i+n])
#storing assumptions values 

assmps=[]

#for 1st sudoku63
for i in b:
    for j in b:
        for p in b:
            if sud_1[i-1][j-1]:  # if there is a non zero value initially
                if(sud_1[i-1][j-1]!=p): # if the correct value is placed, append it else append negative of it. negative implies the number is not present. 
                    assmps.append(int(-n*n*i-n*j-p)) #append the id
                else:
                    assmps.append(int(n*n*i+n*j+p))

#for 2nd sudoku
for i in b:
    for j in b:
        for p in b:
            if sud_2[i-1][j-1]:
                if(sud_2[i-1][j-1]!=p):
                    assmps.append(int(-n*n*n-n*n*i-n*j-p))
                else:
                    assmps.append(int(n*n*n+n*n*i+n*j+p))   
                    
#solving of sudoku
sudoku_solver=Glucose3()
                 

# at least one case

for num in range(2):  # writing for both sudokus at same time
    for i in range(n):
        for j in range(n):
            temp=[]
            for p in b:
                temp.append(int(n*n*n*num+n*n*i+n*j+p))
            sudoku_solver.add_clause(temp)

# at most one case

for num in range(2):
    for i in range(n):
        for j in range(n):
            for p in range(1,n+1):
                for q in range(p+1, n+1):
                    temp=[]
                    temp.append(int(-n*n*n*num-n*n*i-n*j-p))
                    temp.append(int(-n*n*n*num-n*n*i-n*j-q))
                    sudoku_solver.add_clause(temp)

# Each row have all the numbers
for num in range(2):
    for i in range(n):
        for p in b:
            temp=[]
            for j in range(n):
                temp.append(int(n*n*n*num+n*n*i+n*j+p))
            sudoku_solver.add_clause(temp)

# each row have no number twice
for num in range(2):
    for i in range(n):
        for p in b:
            for j1 in range(n):
                for j2 in range(j1+1, n):
                    temp=[]
                    temp.append(int(-n*n*n*num-n*n*i-n*j1-p))
                    temp.append(int(-n*n*n*num-n*n*i-n*j2-p))
                    sudoku_solver.add_clause(temp)

# each column have all the numbers
for num in range(2):
    for j in range(n):
        for p in b:
            temp=[]
            for i in range(n):
                temp.append(int(n*n*n*num+n*n*i+n*j+p))
            sudoku_solver.add_clause(temp)

# each column have no number twice
for num in range(2):
    for j in range(n):
        for p in b:
            for i1 in range(n):
                for i2 in range(i1+1, n):
                    temp=[]
                    temp.append(int(-n*n*n*num-n*n*i1-n*j-p))
                    temp.append(int(-n*n*n*num-n*n*i2-n*j-p))
                    sudoku_solver.add_clause(temp)

# each box have all the numbers
for num in range(2):
    for r in range(k):
        for c in range(k):
            for p in b:
                temp=[]
                for i in range(k*r, k*(r+1)):
                    for j in range(k*c, k*(c+1)):
                      temp.append(int(n*n*n*num+n*n*i+n*j+p))
                sudoku_solver.add_clause(temp)

# both the sudokus have different numbers in same cell
for i in range(n):
    for j in range(n):
        for p in b:
            temp=[]
            temp.append(int(-n*n*i-n*j-p))
            temp.append(int(-n*n*n-n*n*i-n*j-p))
            sudoku_solver.add_clause(temp)
def display(sudoku_solver, k, assmps):
    n=pow(k,2)
    t=0 # returning true or false
    for a in sudoku_solver.enum_models(assumptions = assmps): # standard template of enum model
        solved_spair=[]  
        t=1
        for sudno in range(2):
            for i in b:
                  final_row=[]
                  for j in b:
                      for p in b:
                         l =int(n*n*n*sudno+n*n*(i-1)+n*(j-1)+p)
                         if a[l-1]>0:
                          print(p, end=" ")
                         final_row.append(p)

                  solved_spair.append(final_row)
                  print("\n")
        break

        
        

display(sudoku_solver, k, assmps)
sudoku_solver.delete()


f=open('result1.csv','w')
writer=csv.writer(f)


