import time
start=time.time()
cnf=[]
cnffile = open("uf20-07.cnf", "r")
for line in cnffile:
    if line[0]!="c" and line[0]=="p":
        v=line.split(" ")
        z=v[2]
    if line[0]!="c" and line[0]!="p":
        q=line.split(" 0")[0].strip().split(" ")
        m=[]
        for k in q:
            m.append(int(k))
        cnf.append(m)
cnffile.close()
assgn=[-1 for i in range(int(z)+1)]
def select_literal(cnf):
         return cnf[0][0]
def sat_solver(cnf,assgn):
    temp=0  
    if len(cnf) == 0:
        return True,assgn
 
    if any([len(c)==0 for c in cnf]):
       return False,assgn
 
    lit = (select_literal(cnf))
    if(lit>0):        
     assgn[lit-1]=1
     new_cnf = [c for c in cnf if lit not in c]
     for c in new_cnf:
        if -lit in c:
            c.remove(-lit)
            if len(c)==0:
             temp=1
     new_cnf=[c for c in new_cnf if len(c)!=0] 
     if(temp==1):
        return False,assgn
     sat,assgn= sat_solver(new_cnf,assgn)
     if sat:
        return sat,assgn
     else:
      assgn[lit-1]=0   
     new_cnf_1 = [c for c in cnf if lit not in c]
     for c in new_cnf_1:
        if -lit in c:
            c.remove(-lit)   
            if len(c)==0:
                 temp=1
     new_cnf_1=[c for c in new_cnf_1 if len(c)!=0]
     if(temp==1):
        return False,assgn
     sat,assgn= sat_solver(new_cnf_1,assgn)
     if sat:
        return sat,assgn
 
     return False,assgn
    else:
     assgn[lit+1]=0
    new_cnf = [c for c in cnf if lit not in c]
    for c in new_cnf:
        if -lit in c:
            c.remove(-lit)
            if len(c)==0:
             temp=1
    new_cnf=[c for c in new_cnf if len(c)!=0] 
    if(temp==1):
        return False,assgn
    sat,assgn= sat_solver(new_cnf,assgn)
    if sat:
        return sat,assgn
    else:
      assgn[lit+1]=1   
    new_cnf_1 = [c for c in cnf if lit not in c]
    for c in new_cnf_1:
        if -lit in c:
            c.remove(-lit)   
            if len(c)==0:
                 temp=1
    new_cnf_1=[c for c in new_cnf_1 if len(c)!=0]
    if(temp==1):
        return False,assgn
    sat,assgn= sat_solver(new_cnf_1,assgn)
    if sat:
        return sat,assgn
 
    return False,assgn 
        
a,model=sat_solver(cnf,assgn)
if a:
    print("MODEL:",model)
else:
    print("Formula is unsatisfiable")
    
end=time.time()
print(end-start)